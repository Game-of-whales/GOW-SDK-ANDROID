package com.x3m.gow_test;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import com.gameofwhales.plugin.GOW;
import com.gameofwhales.plugin.GOWDevice;
import com.gameofwhales.plugin.billing.GOWBilling;
import com.gameofwhales.plugin.billing.GOWOrder;
import com.gameofwhales.plugin.billing.GOWStoreItem;
import com.gameofwhales.plugin.billing.specialoffers.GOWReplacement;
import com.gameofwhales.plugin.ui.DefaultAlertDialog;
import com.gameofwhales.plugin.utils.actions.ActionT1;
import com.gameofwhales.plugin.utils.actions.ActionT2;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GOWTestActivity extends AppCompatActivity {

    public static String TAG = "GOWExampleMainActivity";

    private static String[] skus = new String[]{"bucks01", "bucks02", "bucks03", "bucks04", "bucks05", "bucks06"};

    private TextView playerIdText;
    private TextView deviceTokenText;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gowtest);

        playerIdText = (TextView) findViewById(R.id.playerId);
        deviceTokenText = (TextView) findViewById(R.id.deviceToken);

        final Button purchasesButton = (Button) findViewById(R.id.purchasesButton);
        final Button soButton = (Button) findViewById(R.id.soButton);

        purchasesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOW.getPurchases();
            }
        });
        soButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GOW.getSpecialOffers(new ActionT1<String>() {
                    @Override
                    public void doAction(String error) {
                        DefaultAlertDialog.showDialog(getActivity(), "Purchase error",
                                "failed: " + error,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                    }
                                });
                    }
                });
            }
        });

        GOWDevice.playerIdReceived.addListener(new ActionT1<String>() {
            @Override
            public void doAction(final String playerId) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        playerIdText.setText("Player Id: " + playerId);
                    }
                });
            }
        });

        GOWBilling.onItemBoughtSuccess.addListener(new ActionT1<GOWOrder>() {
            @Override
            public void doAction(GOWOrder gowOrder) {
                DefaultAlertDialog.showDialog(getActivity(), "Purchase " + gowOrder.getProductId(),
                        "Complete: " + gowOrder.getPurchaseToken(),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
            }
        });

        GOWBilling.onItemBoughtFailed.addListener(new ActionT1<String>() {
            @Override
            public void doAction(String error) {
                DefaultAlertDialog.showDialog(getActivity(), "Purchase error",
                        "failed: " + error,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
            }
        });

        GOWDevice.tokenReceived.addListener(new ActionT1<String>() {
            @Override
            public void doAction(final String deviceToken) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        deviceTokenText.setText("Device Token: " + deviceToken);
                    }
                });
            }
        });

        final ActionT1<String> buyHandler = new ActionT1<String>() {
            @Override
            public void doAction(String sku) {
                GOW.buy(sku);
            }
        };

        GOWBilling.itemsReceived.addListener(new ActionT2<List<GOWStoreItem>, String>() {
            @Override
            public void doAction(final List<GOWStoreItem> gowStoreItems, String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        GridLayout layout = (GridLayout) findViewById(R.id.gridView);
                        layout.removeAllViews();

                        Collections.sort(gowStoreItems, new Comparator<GOWStoreItem>() {
                            @Override
                            public int compare(GOWStoreItem storeItem, GOWStoreItem t1) {
                                return Double.valueOf(storeItem.getFloatPrice()).compareTo(Double.valueOf(t1.getFloatPrice()));
                            }
                        });

                        for (int i = 0; i < gowStoreItems.size(); i++) {
                            final GOWStoreItem storeItem = gowStoreItems.get(i);

                            if (storeItem.isSpecialOfferProduct()) {
                                continue;
                            }

                            Button button = new Button(getActivity());

                            String title = storeItem.getPrice();

                            GOWReplacement soReplacement = storeItem.getReplacement();

                            if (soReplacement != null) {
                                title += " [" + soReplacement.getProduct().getPrice() + "]";
                            }

                            button.setText(title);

                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    buyHandler.doAction(storeItem.getSku());
                                }
                            });
//                            button.setCompoundDrawablesWithIntrinsicBounds(resources.getIdentifier(storeItem.getSku(), "drawable", getActivity().getPackageName()), 0, 0, 0);

                            int column = i % 3;
                            int line = i / 3;

                            GridLayout.Spec columnSpec = GridLayout.spec(column);
                            GridLayout.Spec lineSpec = GridLayout.spec(line);

                            GridLayout.LayoutParams params = new GridLayout.LayoutParams(lineSpec, columnSpec);
                            layout.addView(button, params);
                        }

                        soButton.setVisibility(View.VISIBLE);
                    }
                });
            }
        });


        GOW.init(getActivity(), skus);
        purchasesButton.setVisibility(View.VISIBLE);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        GOW.close();
    }

    private Activity getActivity() {
        return this;
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("GOWTest Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }
}
